/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Chat;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dev
 */
public class Cliente {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String host = "localhost";
		int puerto = 6000;
			//Creando Cliente
		try (Socket cliente = new Socket(host, puerto);
				) {

			Cliente_Oyente oyente = new Cliente_Oyente(cliente);
			oyente.start();
			String comando;
			Mensaje m;
			ObjectOutputStream out=null;
			while (true) {
				System.out.print("-> ");
				comando = sc.nextLine();
				System.out.println (" Enviando "+comando);
				 out = new ObjectOutputStream(cliente.getOutputStream());
				 out.writeObject(new Mensaje(comando,""));		
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

}