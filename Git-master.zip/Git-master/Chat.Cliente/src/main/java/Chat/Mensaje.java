package Chat;

import java.io.Serializable;

public class Mensaje implements Serializable{
	private String idOrigen;
	private String texto;

	public Mensaje(String txt, String idOrigen) {
		this.texto = txt;
		this.idOrigen = idOrigen;
	}

	public String getIdOrigen() {
		return idOrigen;
	}

	public void setIdOrigen(String idOrigen) {
		this.idOrigen = idOrigen;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String txt) {
		this.texto = txt;
	}
}

