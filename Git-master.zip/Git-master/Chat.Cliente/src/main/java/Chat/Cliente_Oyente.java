package Chat;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.Socket;

public class Cliente_Oyente extends Thread {

	private Socket cliente;

	public Cliente_Oyente(Socket s) {
		this.cliente = s;
	}

	@Override
	public void run() {

		try{
			Mensaje m;
			ObjectInputStream inp=null;
			while (true) {
				try {
					 inp = new ObjectInputStream(cliente.getInputStream());
					m=(Mensaje) inp.readObject();
					System.out.println("Mensaje recibido de "+m.getIdOrigen() + " ---- "+ m.getTexto());
					System.out.println("-> ");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		

	}
}
