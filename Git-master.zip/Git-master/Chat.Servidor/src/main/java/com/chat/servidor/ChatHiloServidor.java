/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chat.servidor;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import Chat.Mensaje;

/**
 *
 * @author dev
 */
public class ChatHiloServidor extends Thread {

	private String id;
	private Socket socket = null;
	private ObjetoCompartido obj_compartido = null;

	public ChatHiloServidor(int id, Socket s, ObjetoCompartido obj_compartido) {
		this.id = Integer.toString(id);
		this.socket = s;
		this.obj_compartido = obj_compartido;
	}

	@Override
	public void run() { //Tarea a realizar con el cliente
		Mensaje m;
		// Añadiendo al usuario al objetoCompartido
		obj_compartido.add(id, socket);

		
		
		//Creando la entradas y salida de datos
		try {
					ObjectInputStream inp=null;
					
					do{//Bucle hasta .exit
						// Leer lo mandado por el cliente
						 inp = new ObjectInputStream(socket.getInputStream());					
					m = (Mensaje) inp.readObject();
					System.out.println("Recibido " +m.getTexto());
					
					//Darle al mensaje el idOrigen que le corresponde
					m.setIdOrigen(id);
					
					//Si es distinto de exit pues envio a los demas
					if(!m.getTexto().equalsIgnoreCase(".exit")) {
						
						this.obj_compartido.mensajeGeneral(m);		
					}
					
					}while(!(m.getTexto().equalsIgnoreCase(".exit")));
					
				}catch( ClassNotFoundException e) {
					e.printStackTrace();
				}catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				} finally {
				try {
					socket.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	}
}
