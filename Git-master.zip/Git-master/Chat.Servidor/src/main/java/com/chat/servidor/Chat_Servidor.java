/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chat.servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author dev
 */
public class Chat_Servidor {
	private static int id = 0;

	public static void main(String[] args) {

		// Crear ObjetoCompartido para todos los clientes
		ObjetoCompartido obj_compartido = new ObjetoCompartido();

		// Crear servidor
		int puerto = 6000;
		try (ServerSocket servidor = new ServerSocket(puerto);) {
			System.out.println("Iniciando Servidor...");

			while (true) {
				
				// Aceptando cliente
				Socket cliente;
				cliente = servidor.accept();
				System.out.println("Ha llegado el cliente "+id +" "+cliente.toString());
				
				// Cambiando ID proximo cliente
				id++;
				
				// Lanzando un hilo para atender al cliente
				ChatHiloServidor hiloServidor = new ChatHiloServidor(id, cliente, obj_compartido);
				hiloServidor.start();								
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
