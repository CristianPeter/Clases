/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.chat.servidor;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import Chat.Mensaje;

/**
 *
 * @author dev
 */
public class ObjetoCompartido {
	Map<String, Socket> lista_clientes;

	public ObjetoCompartido() {
		lista_clientes = new HashMap();
		ArrayList<String> comandos = new ArrayList<String>() {
			{
				add(".listUsers");
				add(".exit");
				add(".private");
				add(".listChannels");
				add(".listMyChannels ");
				add(".join");
				add(".channel");
				add(".leave");
				add(".createChannel");
				add(".help");
			}
		};
	}

	public synchronized void add(String id, Socket s) {
		this.lista_clientes.put(id, s);
	}

	public synchronized void remove(String id, Socket s) {
		this.lista_clientes.remove(id);
	}

	public void mensajeGeneral(Mensaje m) {
		//Creamos el objeto fuera a nulo dado que no lo podemos meter en un try catch with resources porque
		//se cerraria terminando la comunicacion del Socket 
		
		ObjectOutputStream out = null;
		try {
			
			//Recorremos todos los clientes que se han unido y les enviamos el mensaje escrito por uno de los clientes
			for (Map.Entry<String, Socket> entry : lista_clientes.entrySet()) {
				String key = entry.getKey();
				Socket val = entry.getValue();
				
				//Para no escribirnos a nosotros mismos
				if (!key.equals(m.getIdOrigen())) {
					out = new ObjectOutputStream(val.getOutputStream());
					out.writeObject(m);
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

	}

}
